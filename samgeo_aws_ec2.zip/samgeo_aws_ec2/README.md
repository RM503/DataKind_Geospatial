# Running segment-geospatial on AWS EC2 instances

This directory contains modules for running `segment-geospatial` on AWS EC2 instances.